# -*- coding: utf-8 -*-
"""
Created on Sat Sep 12 13:31:50 2020

@author: Ad
"""
# -*- coding: utf-8 -*-
"""
Created on Sat Sep 12 13:21:47 2020

@author: Derui
"""
import pandas as pd
import pandas_datareader.data as web
import numpy as np
import warnings
warnings.filterwarnings('ignore')
import quandl
import os
import matplotlib.pyplot as plt
from scipy.optimize import fmin

import numpy.matlib
from TAU_P import TAU_P
from EFK_SRTSM import EFK_SRTSM
from matplotlib.backends.backend_pdf import PdfPages
import datetime as dt


def yield_to_forward(yield_df):
    
    def maturity_str_to_num(m):
        if m[-1]=="M":
            return int(m[:-1])*0.25
        
        if m[-1]=="Y":
            return int(m[:-1])
    
    maturities = [maturity_str_to_num(x) for x in yield_df.columns]
    maturities = np.array(maturities)
    maturities_diff = np.diff(maturities)
    
    T,n = yield_df.shape
    forward_rate = yield_df.values[:,:-1]  + (maturities[1:] * (np.diff(yield_df,axis=1)/maturities_diff))
    forward_rate = np.c_[yield_df.values[:,0],forward_rate]
    
    cols = ["f"+str(maturities[i])+","+str(maturities[i+1]) for i in range(n-1)]
    cols.insert(0,'f0,'+str(yield_df.columns[0]))   
  
    forward_df = pd.DataFrame(forward_rate,columns=cols,index=yield_df.index)
    
    return forward_df, maturities


def get_forward_df(key, sdate, edate, maturities):
    symbol = "USTREASURY/YIELD"  
    df_T = web.DataReader(symbol, 'quandl', 
                                   start=sdate, 
                                   end=edate, 
                                   api_key=key)
    
    
    df_T.drop(['2MO'],axis=1,inplace=True)
    df_T.dropna(inplace=True)
    df_T = df_T.sort_index(ascending=True)
    
    
    df_T["month"] = [dt.datetime.strftime(x,"%Y%m") for x in df_T.index]
    df_M = df_T.groupby("month").mean()
    maturities_diff = np.diff(maturities)
    T,n = df_M.shape
    
    
    forward_rate = df_M.values[:,:-1]  + (maturities[1:] * (np.diff(df_M,axis=1)/maturities_diff))
    forward_rate = np.c_[df_M.values[:,0],forward_rate]
    cols = ["f"+str(maturities[i])+","+str(maturities[i+1]) for i in range(n-1)]
    cols.insert(0,'f0,1/12')
    forward_df = pd.DataFrame(forward_rate,columns=cols,index=df_M.index)
    
    return forward_df


def calibrate_parameters(forward_df, maturities, LB, split_date, print_log=True):
    maturities = np.append(maturities[::-1], 0.0)[::-1]
    maturities = np.array(maturities[1:])*12
    maturities = np.array(maturities, dtype=int)

    
    train_df = forward_df[forward_df.index<split_date]
    forwardrates = train_df.values

    def decorated_cost(parameters):
        parameters = np.append(parameters, LB)
        return EFK_SRTSM(parameters, maturities, forwardrates, 0)

    starttime = dt.datetime.now()
    xopt = fmin(decorated_cost, startv, maxiter= 1e6, full_output=True)
    parameters = xopt[0]
    nparam = np.append(parameters, LB) # lower-bound

    if print_log:
        print ("======== shadow rate term structure model========\n")
        print("lower_bound=", LB)
        print ("The log likelihood value is:", -EFK_SRTSM(nparam, maturities, train_df.values, 0))
        endtime = dt.datetime.now()
        print((endtime - starttime).seconds)
        
    parameters_df = pd.DataFrame(parameters)
    return parameters_df


    
if __name__ == "__main__":
    
    
    key = "fFQBXFkYyxsDvRibinGz"
    quandl.ApiConfig.api_key = key

    sdate = '2006-01-01'
    edate = '2020-09-01'
    symbol = "MOFJ/INTEREST_RATE_JAPAN"  

    parameters = pd.read_excel("trial20200901_0123.xlsx").iloc[:,1].values
    startv = parameters
    epsilon = 1e3 
    split_date = "201801"
    print(split_date)
    
    
    df_JP = web.DataReader(symbol,
                           'quandl',
                           start='2006-01-01',
                           end='2020-09-01',
                           api_key=key)
    df_JP.drop(['40Y'],axis=1,inplace=True)
    df_JP["month"] = [dt.datetime.strftime(x,"%Y%m") for x in df_JP.index]
    df_JP_M = df_JP.groupby("month").mean()
    
    
    yield_df = df_JP_M
    forward_df, maturities = yield_to_forward(yield_df)
    # LB_lst = [-2.5, -1.25, -0.75, -0.25, 0.0, 0.25, 0.75, 1.25, 2.5]
    LB_lst = [-2.5, -1.25, -0.75, -0.25, 0.0, 0.25, 0.75, 1.25]
    
    """
    each run takes 30 - 60 minutes
    """
    parameters_path = "parameters\\"
    trial = "JP20201014"
    for LB in LB_lst:
        parameters_df = calibrate_parameters(forward_df, maturities, LB, split_date, print_log=True)
        parameters_df.to_excel(parameters_path +
                               "parameters" +
                               trial + 
                               "_LB="+str(LB)+ 
                               "splitDate="+split_date+ 
                               ".xlsx")
