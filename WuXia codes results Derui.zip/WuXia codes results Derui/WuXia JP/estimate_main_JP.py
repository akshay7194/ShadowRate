# -*- coding: utf-8 -*-
"""
Created on Thu Nov 12 18:09:15 2020

@author: Ad
"""
from lower_bound_sensitivity_v2 import *


def yield_to_forward(yield_df):
    
    def maturity_str_to_num(m):
        if m[-1]=="M":
            return int(m[:-1])*0.25
        
        if m[-1]=="Y":
            return int(m[:-1])
    
    maturities = [maturity_str_to_num(x) for x in yield_df.columns]
    maturities = np.array(maturities)
    maturities_diff = np.diff(maturities)
    
    T,n = yield_df.shape
    forward_rate = yield_df.values[:,:-1]  + (maturities[1:] * (np.diff(yield_df,axis=1)/maturities_diff))
    forward_rate = np.c_[yield_df.values[:,0],forward_rate]
    
    cols = ["f"+str(maturities[i])+","+str(maturities[i+1]) for i in range(n-1)]
    cols.insert(0,'f0,'+str(yield_df.columns[0]))   
  
    forward_df = pd.DataFrame(forward_rate,columns=cols,index=yield_df.index)
    
    return forward_df, maturities


if __name__ == "__main__":
    symbol = "MOFJ/INTEREST_RATE_JAPAN"  
    key = "fFQBXFkYyxsDvRibinGz"
    quandl.ApiConfig.api_key = key

    sdate = '2006-01-01'
    edate = '2020-09-01'

    parameters = pd.read_excel("trial20200901_0123.xlsx").iloc[:,1].values
    startv = parameters
    epsilon = 1e3 
    split_date = "202010"
    print("split_date:", split_date)
    
    df_JP = web.DataReader(symbol,
                           'quandl',
                           start='2006-01-01',
                           end='2020-09-01',
                           api_key=key)
    
    df_JP.drop(['40Y'],axis=1,inplace=True)
    df_JP["month"] = [dt.datetime.strftime(x,"%Y%m") for x in df_JP.index]
    df_JP_M = df_JP.groupby("month").mean()
    
    
    yield_df = df_JP_M
    forward_df, maturities = yield_to_forward(yield_df)

    # LB_lst = [-2.5, -1.25, -0.75, -0.25, 0.0, 0.25, 0.75, 1.25, 2.5]
    LB_lst = [-0.1, None, 0.1]
    startv = pd.read_excel("trial20200901_0123.xlsx").iloc[:,1].values # initial parameters
    
    parameters_path = "parameters\\"
    trial = "JP20201014"
    
    
    # create directories if they don't exist
    if not os.path.exists(parameters_path):
        os.makedirs(parameters_path)
    
    # each run takes 30 - 60 minutes

    for LB in LB_lst:
        parameters_df = calibrate_parameters(forward_df, maturities, LB, split_date, startv, print_log=True)
        parameters_df.to_excel(parameters_path +
                               "parameters" +
                               trial + 
                               "_LB="+str(LB)+ 
                               "splitDate="+split_date+ 
                               ".xlsx")
    