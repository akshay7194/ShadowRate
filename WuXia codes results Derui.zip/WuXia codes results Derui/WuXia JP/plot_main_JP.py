# -*- coding: utf-8 -*-
"""
Created on Thu Nov 12 19:35:34 2020

@author: Ad
"""
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 29 21:02:59 2020

@author: Derui
"""
from plot_shadow_rates import *

def yield_to_forward(yield_df):
    
    def maturity_str_to_num(m):
        if m[-1]=="M":
            return int(m[:-1])*0.25
        
        if m[-1]=="Y":
            return int(m[:-1])
    
    maturities = [maturity_str_to_num(x) for x in yield_df.columns]
    maturities = np.array(maturities)
    maturities_diff = np.diff(maturities)
    
    T,n = yield_df.shape
    forward_rate = yield_df.values[:,:-1]  + (maturities[1:] * (np.diff(yield_df,axis=1)/maturities_diff))
    forward_rate = np.c_[yield_df.values[:,0],forward_rate]
    
    cols = ["f"+str(maturities[i])+","+str(maturities[i+1]) for i in range(n-1)]
    cols.insert(0,'f0,'+str(yield_df.columns[0]))   
  
    forward_df = pd.DataFrame(forward_rate,columns=cols,index=yield_df.index)
    
    return forward_df, maturities
    
    
    
if __name__ == "__main__":
    # parameters specification
    symbol = "MOFJ/INTEREST_RATE_JAPAN"  
    key = "fFQBXFkYyxsDvRibinGz"
    quandl.ApiConfig.api_key = key

    sdate = '2006-01-01'
    edate = '2020-09-01'
    
    

    df_JP = web.DataReader(symbol,
                           'quandl',
                           start='2006-01-01',
                           end='2020-09-01',
                           api_key=key)
    
    df_JP.drop(['40Y'],axis=1,inplace=True)
    df_JP["month"] = [dt.datetime.strftime(x,"%Y%m") for x in df_JP.index]
    df_JP_M = df_JP.groupby("month").mean()
    
    
    yield_df = df_JP_M
    forward_df, maturities = yield_to_forward(yield_df)
    
    # LB_lst = [-2.5, -1.25, -0.75, -0.25, 0.0, 0.25, 0.75, 1.25, 2.5]
    LB_lst = [None, -2.5, -1.25, -0.75, -0.25, -0.1, 0.0, 0.1, 0.25, 0.75]
    
    split_date_lst = ["201401", "201801", "202010"]
    color_lst = ["b", "g", "y"]

    trial = "JP20201014"
    img_path = "images\\"
    result_path = "results\\"
    parameters_path = "parameters\\"
    
    
    gen_all_result(forward_df,
                   maturities,
                   trial,
                   LB_lst,
                   split_date_lst,
                   color_lst,
                   img_path=img_path,
                   result_path=result_path,
                   parameters_path = parameters_path)