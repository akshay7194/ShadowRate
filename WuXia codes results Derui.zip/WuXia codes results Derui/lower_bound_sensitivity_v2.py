# -*- coding: utf-8 -*-
"""
Created on Sat Sep 12 13:31:50 2020

@author: Derui
"""
# -*- coding: utf-8 -*-
"""
Created on Sat Sep 12 13:21:47 2020

@author: Derui
"""
import pandas as pd
import pandas_datareader.data as web
import numpy as np
import warnings
warnings.filterwarnings('ignore')
import quandl
import os
import matplotlib.pyplot as plt
from scipy.optimize import fmin

import numpy.matlib
from TAU_P import TAU_P
from EFK_SRTSM import EFK_SRTSM
from matplotlib.backends.backend_pdf import PdfPages
import datetime as dt


def get_forward_df(key, sdate, edate, maturities):
    """
    Get US Treasury Yield from quandl and processed into forward rate
    
    Parameters
    ----------
    key : str
        Password for quandl account
    sdate : str (%Y%m)
        Start date of data
    edate : str (%Y%m)
        End date of data
    maturities : np.array
        Maturities (year), must be integer when converted to monthly

    Returns
    -------
    forward_df : pd.DataFrame
        values=forward rates, index=str("%Y%m"), columns=maturities          
    """
    
    symbol = "USTREASURY/YIELD"  
    df_T = web.DataReader(symbol, 'quandl', 
                                   start=sdate, 
                                   end=edate, 
                                   api_key=key)
    
    
    df_T.drop(['2MO'],axis=1,inplace=True)
    df_T.dropna(inplace=True)
    df_T = df_T.sort_index(ascending=True)
    
    
    df_T["month"] = [dt.datetime.strftime(x,"%Y%m") for x in df_T.index]
    df_M = df_T.groupby("month").mean()
    maturities_diff = np.diff(maturities)
    T,n = df_M.shape
    
    
    forward_rate = df_M.values[:,:-1]  + (maturities[1:] * (np.diff(df_M,axis=1)/maturities_diff))
    forward_rate = np.c_[df_M.values[:,0],forward_rate]
    cols = ["f"+str(maturities[i])+","+str(maturities[i+1]) for i in range(n-1)]
    cols.insert(0,'f0,1/12')
    forward_df = pd.DataFrame(forward_rate,columns=cols,index=df_M.index)
    
    return forward_df


def calibrate_parameters(forward_df, maturities, LB, split_date, startv, print_log=True):
    """
    calibrate parameters for Wu&Xia(2016) SRTSM
    
    Parameters
    ----------
    forward_df : pd.DataFrame
        values=forward rates, index=str("%Y%m"), columns=maturities
    maturities : np.array
        Maturities (year), must be integer when converted to monthly
    LB : float
        lower bound parameter
    split_date : str("%Y%m")
        Train data cutoff
    print_log : boolean
        Whether to print optimization result

    Returns
    -------
    parameters_df : pd.DataFrame
          Optimized parameters. shape=(22,1)
    """
    
    if LB == None:
        return calibrate_parameters_LB_free(forward_df, maturities, split_date, startv, print_log=True)
    
    
    # should be same as maturities = np.array(maturities)*12
    maturities = np.append(maturities[::-1], 0.0)[::-1]
    maturities = np.array(maturities[1:])*12
    maturities = np.array(maturities, dtype=int)
    # forwardrates = forward_df.values
    
    train_df = forward_df[forward_df.index<split_date]
    forwardrates = train_df.values

    def decorated_cost(parameters):
        from EFK_SRTSM import EFK_SRTSM
        parameters = np.append(parameters, LB)
        return EFK_SRTSM(parameters, maturities, forwardrates, 0)


    startv = pd.read_excel("trial20200901_0123.xlsx").iloc[:,1].values
    starttime = dt.datetime.now()
    xopt = fmin(decorated_cost, startv, maxiter= 1e6, full_output=True)
    parameters = xopt[0]
    nparam = np.append(parameters, LB) # lower-bound

    if print_log:
        print ("======== shadow rate term structure model========\n")
        print("lower_bound=", LB)
        print ("The log likelihood value is:", -EFK_SRTSM(nparam, maturities, train_df.values, 0))
        endtime = dt.datetime.now()
        print((endtime - starttime).seconds)
        
    parameters_df = pd.DataFrame(parameters)
    return parameters_df




def calibrate_parameters_LB_free(forward_df, maturities, split_date, startv, print_log=True):
    """
    calibrate parameters for Wu&Xia(2016) SRTSM, LB as a free parameter
    
    Parameters
    ----------
    forward_df : pd.DataFrame
        values=forward rates, index=str("%Y%m"), columns=maturities
    maturities : np.array
        Maturities (year), must be integer when converted to monthly
    split_date : str("%Y%m")
        Train data cutoff
    print_log : boolean
        Whether to print optimization result

    Returns
    -------
    parameters_df : pd.DataFrame
          Optimized parameters. shape=(22,1)
    """
    
    maturities = np.append(maturities[::-1], 0.0)[::-1]
    maturities = np.array(maturities[1:])*12
    maturities = np.array(maturities, dtype=int)

    
    train_df = forward_df[forward_df.index<split_date]
    forwardrates = train_df.values


    # startv = pd.read_excel("trial20200901_0123.xlsx").iloc[:,1].values
    # startv = pd.read_excel("parameters\\parametersUK20201023_LB=0.0splitDate=202010.xlsx").iloc[:,1].values
    startv = np.append(startv, 0.0)
    starttime = dt.datetime.now()
    
    cost_func = lambda x: EFK_SRTSM(x, maturities, forwardrates, 0)
    xopt = fmin(cost_func, startv, maxiter= 1e6, full_output=True)
    parameters = xopt[0]
    LB = parameters[-1]
    nparam = np.append(parameters, LB) # lower-bound

    if print_log:
        print ("======== shadow rate term structure model========\n")
        print("best lower_bound=", LB)
        print ("The log likelihood value is:", -EFK_SRTSM(nparam, maturities, train_df.values, 0))
        endtime = dt.datetime.now()
        print((endtime - starttime).seconds)
        
    parameters_df = pd.DataFrame(parameters)
    return parameters_df


