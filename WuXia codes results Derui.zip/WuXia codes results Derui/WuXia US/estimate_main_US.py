# -*- coding: utf-8 -*-
"""
Created on Fri Oct 30 20:50:18 2020

@author: Ad
"""
from lower_bound_sensitivity_v2 import *

if __name__ == "__main__":

    key = "fFQBXFkYyxsDvRibinGz"
    quandl.ApiConfig.api_key = key

    sdate = '2006-01-01'
    edate = '2020-09-01'
    maturities = np.array([1, 3, 6, 12, 24, 36, 60, 84, 120, 240, 360])/12
    parameters = pd.read_excel("trial20200901_0123.xlsx").iloc[:,1].values
    startv = parameters
    epsilon = 1e3 
    split_date = "201401"
    print("split_date:", split_date)
    
    forward_df = get_forward_df(key, sdate, edate, maturities)
    LB_lst = [-2.5, -1.25, -0.75, -0.25, 0.0, 0.25, 0.75, 1.25, 2.5]
    # LB_lst = [-0.1, None, 0.1]
    LB_lst = [None]
    startv = pd.read_excel("parameters\\parameters20201008_LB=0.25splitDate=202010.xlsx").iloc[:,1].values # initial parameters
    
    parameters_path = "parameters\\"
    trial = "20201008"
    
    
    # create directories if they don't exist
    if not os.path.exists(parameters_path):
        os.makedirs(parameters_path)
    
    
    # each run takes 30 - 60 minutes

    for LB in LB_lst:
        parameters_df = calibrate_parameters(forward_df, maturities, LB, split_date, startv, print_log=True)
        parameters_df.to_excel(parameters_path +
                               "parameters" +
                               trial + 
                               "_LB="+str(LB)+ 
                               "splitDate="+split_date+ 
                               ".xlsx")
    