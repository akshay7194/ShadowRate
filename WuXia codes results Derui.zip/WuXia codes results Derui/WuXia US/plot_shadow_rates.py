# -*- coding: utf-8 -*-
"""
Created on Sat Sep 12 17:17:14 2020

@author: Derui
"""
import pandas as pd
import pandas_datareader.data as web
import numpy as np
import warnings
warnings.filterwarnings('ignore')
import quandl
import os
import matplotlib.pyplot as plt
from scipy.optimize import fmin

import numpy.matlib
from TAU_P import TAU_P
from EFK_SRTSM import EFK_SRTSM
from matplotlib.backends.backend_pdf import PdfPages
import datetime as dt

from lower_bound_sensitivity_v2 import get_forward_df



def cal_SR(trial, LB, maturities, forward_df, split_date, parameters_path="parameters\\"):
    """
    calculate Shadow Rate with given parameters
    
    Parameters
    ----------
    trial : str
        Trial name
    LB : float
        Lower bound parameter
    maturities : list
        Maturities (year)
    forward_df : pd.DataFrame
        Forward rates
    parameters_path : str
        File path for reading xlsx containing parameters

    Returns
    -------
    SR : np.array
        shadow rates        
    """
    
    train_df = forward_df[forward_df.index<split_date]
    test_df = forward_df[forward_df.index>=split_date]
    
    maturities = np.append(maturities[::-1], 0.0)[::-1]
    maturities = np.array(maturities[1:])*12
    maturities = np.array(maturities, dtype=int)
    
    param_fname = parameters_path + "parameters" + trial + "_LB="+str(LB)+ "splitDate="+split_date+ ".xlsx"
    parameters = pd.read_excel(param_fname).iloc[:,1].values
    parameters_df = pd.DataFrame(parameters)
    nparam = np.append(parameters, LB) 
    
    
    rhoP = parameters[0:9];
    rhoP = np.reshape(rhoP, [3,3], order='F')
    muP = parameters[9:12]
    rhoQ1 = parameters[12]; rhoQ2 = parameters[13];
    rhoQ = np.zeros((3, 3)); np.fill_diagonal(rhoQ, [rhoQ1, rhoQ2, rhoQ2])
    rhoQ[1, 2] = 1
    sigma = [[abs(parameters[14]), 0, 0],
            [parameters[15], abs(parameters[17]), 0],
            [parameters[16], parameters[18], abs(parameters[19])]]
    delta0 = parameters[20]
    sqrt_omega = parameters[21]
    
    
    dateList = train_df.index
    dateList = [dt.datetime(int(x[:4]), int(x[4:]), 1) for x in dateList]

    SR = EFK_SRTSM(nparam,maturities,forward_df.values,1)
    
    return SR



def plot_same_split_date(trial, LB_lst, maturities, forward_df, split_date, parameters_path="parameters\\", img_path="images\\", new_fig=True):
    """
    plot shadow rate timeseries for a given split_date, for different parameters, on the same graph
    
    Parameters
    ----------
    trial : str
        Trial name
    LB_lst : list
        List containing lower bound parameters
    maturities : list
        Maturities (year)
    forward_df : pd.DataFrame
        Forward rates
    split_date : str (%Y%m)
        Split_date
    parameters_path : str
        File path for reading xlsx containing parameters
    img_path : str
        File path for writing output images
    new_fig : boolean
        Whether to use initiate a new matplotlib figure
        
    Returns
    -------
    None
    
    """
        
        
    LB_num = len(LB_lst)
    dateList = [dt.datetime(int(x[:4]), int(x[4:]), 1) for x in forward_df.index]

    plt.figure(figsize=(12,4))    
    for i in range(len(LB_lst)):
        LB = LB_lst[i]
        SR = cal_SR(trial, LB, maturities, forward_df, split_date, parameters_path)
        plt.plot(dateList, SR)
    
    legend_lst = [str(x) for x in LB_lst]
    plt.legend(legend_lst)
    plt.title(split_date)
    
    if new_fig:  
      title = 'Plot of estimated shadow rate,split_date='+split_date
      plt.title(title, fontsize = 18)
      plt.savefig(img_path + "trial" + trial + "_split_date="+split_date+"_plot.png") 
      


def gen_result(trial, LB, maturities, forward_df, split_date, parameters_path="parameters\\", img_path="images\\", new_fig=True):
    """
    Generate results for a given split_date and given LB
    1. calculate and plot shadow rate estimation insample/outsample
    2. calculcate insample/wholesample log likelihood
    
    
    Parameters
    ----------
    trial : str
        Trial name
    LB : float
        Lower bound parameter
    maturities : list
        Maturities (year)
    forward_df : pd.DataFrame
        Forward rates
    split_date : str (%Y%m)
        Split_date
    parameters_path : str
        File path for reading xlsx containing parameters
    img_path : str
        File path for writing output images
    new_fig : boolean
        Whether to use initiate a new matplotlib figure
        
    Returns
    -------
    all_result : pd.DataFrame
        Shadow rates estimation time series
    parameters_df : pd.DataFrame
        DataFrame containing parameters
    llh : float
        Insample loglikelihood
    llh_OS : float
        Wholesample loglikelihood
    """

    train_df = forward_df[forward_df.index<split_date]
    test_df = forward_df[forward_df.index>=split_date]
    maturities = np.append(maturities[::-1], 0.0)[::-1]
    maturities = np.array(maturities[1:])*12
    maturities = np.array(maturities, dtype=int)
    
    param_fname = parameters_path + "parameters" + trial + "_LB="+str(LB)+ "splitDate="+split_date+ ".xlsx"
    parameters = pd.read_excel(param_fname).iloc[:,1].values
    parameters_df = pd.DataFrame(parameters)
    nparam = np.append(parameters, LB) 
    
    
    rhoP = parameters[0:9];
    rhoP = np.reshape(rhoP, [3,3], order='F')
    muP = parameters[9:12]
    rhoQ1 = parameters[12]; rhoQ2 = parameters[13];
    rhoQ = np.zeros((3, 3)); np.fill_diagonal(rhoQ, [rhoQ1, rhoQ2, rhoQ2])
    rhoQ[1, 2] = 1
    sigma = [[abs(parameters[14]), 0, 0],
            [parameters[15], abs(parameters[17]), 0],
            [parameters[16], parameters[18], abs(parameters[19])]]
    delta0 = parameters[20]
    sqrt_omega = parameters[21]
    
    
    dateList = train_df.index
    dateList = [dt.datetime(int(x[:4]), int(x[4:]), 1) for x in dateList]


    SR = EFK_SRTSM(nparam,maturities,forward_df.values,1)
    llh = -EFK_SRTSM(nparam,maturities,train_df.values,0)
    llh_OS = -EFK_SRTSM(nparam,maturities,forward_df.values,0)
    
    
    SR_train = SR[forward_df.index < split_date]
    SR_test = SR[forward_df.index >= split_date]

    
    if new_fig:
        plt.figure(figsize=(10,4))
    
    dateList_all = [dt.datetime(int(x[:4]), int(x[4:]), 1) for x in forward_df.index]
    dateList_train = [dt.datetime(int(x[:4]), int(x[4:]), 1) for x in train_df.index]
    dateList_test = [dt.datetime(int(x[:4]), int(x[4:]), 1) for x in test_df.index]
    
    plt.plot(dateList_all, SR, 'b')
    plt.plot(dateList_test, SR_test, 'r')

    
    if new_fig:  
        title = 'Plot of estimated shadow rate,' + "LB="+str(LB) + ",split_date="+split_date
        plt.title(title, fontsize = 18)
        plt.savefig(img_path + "trial" + trial + "_LB=" +str(LB)+"_split_date="+split_date+"_plot.png")
    else:
        title = "LB="+str(LB) + ",split_date="+split_date
        plt.title(title, fontsize = 18)
    
    
    SR = np.r_[SR_train, SR_test]
    idx = train_df.index.tolist() + test_df.index.tolist()
    all_result = pd.DataFrame(SR.reshape(-1,1), columns=["SR"], index=idx)
    return all_result, parameters_df, llh, llh_OS



def plot_SR_v2(trial, LB, maturities, forward_df, split_date, parameters_path="parameters\\", img_path="images\\", new_fig=True, color='b'):
    """
    plot shadow rate with given color
    
    Parameters
    ----------
    trial : str
        Trial name
    LB : float
        Lower bound parameter
    maturities : list
        Maturities (year)
    forward_df : pd.DataFrame
        Forward rates
    split_date : str (%Y%m)
        Split_date
    parameters_path : str
        File path for reading xlsx containing parameters
    img_path : str
        File path for writing output images
    new_fig : boolean
        Whether to use initiate a new matplotlib figure
    color : str
        Matplotlib color
        
    Returns
    -------
    None
    """
    train_df = forward_df[forward_df.index<split_date]
    test_df = forward_df[forward_df.index>=split_date]
    
    SR = cal_SR(trial, LB, maturities, forward_df, split_date, parameters_path="parameters\\")
    SR_train = SR[forward_df.index<split_date]
    SR_test = SR[forward_df.index>=split_date]

    
    if new_fig:
        plt.figure(figsize=(10,4))
    
    dateList_all = [dt.datetime(int(x[:4]), int(x[4:]), 1) for x in forward_df.index]
    dateList_train = [dt.datetime(int(x[:4]), int(x[4:]), 1) for x in train_df.index]

    plt.plot(dateList_all, SR, color)

    if new_fig:  
        title = 'Plot of estimated shadow rate,' + "LB="+str(LB) + ",split_date="+split_date
        plt.savefig(img_path + "trial" + trial + "_LB=" +str(LB)+"_split_date="+split_date+"_plot.png")
    else:
        title = "LB="+str(LB) + ",split_date="+split_date    



def gen_all_result(forward_df, maturities, trial, LB_lst, split_date_lst, color_lst, img_path="images\\", result_path="results\\", parameters_path = "parameters\\"):
    """
    Generate all results
    1. Shadow rate subplots
    2. Aggregate parameters, one xlsx file for each split_date
    3. Aggregate Shadow rates, one xlsx file for each split_date
    4. Aggregate loglikelihood values, one xlsx file for IS and OS each
    5. plot results for different split_date on same graph. One graph for each LB
    6. plot results for different LB on same graph. One Graph for each split_date
    
    Parameters
    ----------
    forward_df : pd.DataFrame
        Forward rates
    maturities : list
        Maturities (year)
    trial : str
        Trial name
    LB_lst : list, float
        Lower bound parameters
    split_date_lst : list, str(%Y%m)
        Split_date parameters
    color_lst : list
        List containing colors. Size same as split_date_lst
    img_path : str
        file path for writing output images
    result_path : str
        file path for writing output results
    parameters_path : str
        file path for reading parameters
        
    Returns
    -------
    None
    """
    dateList_all = [dt.datetime(int(x[:4]), int(x[4:]), 1) for x in forward_df.index]


    # across each split_date
    llh_df = []
    llh_df_OS = []
    LB_num = len(LB_lst)
    for split_date in split_date_lst:
        figsize = (24, int(4*(np.ceil(10/3))))
        plt.figure(figsize=figsize)
        
        
        all_SR_df = []
        all_param_df = []
        llh_df_tmp = []
        llh_df_OS_tmp = []
        
        # across each LB
        for i in range(len(LB_lst)):
            LB = LB_lst[i]
            plt.subplot(int(np.ceil(LB_num/3)), 3, 1+i)
            result_LB, param_LB, llh, llh_OS = gen_result(trial, 
                                                           LB, 
                                                           maturities, 
                                                           forward_df, 
                                                           split_date,
                                                           parameters_path=parameters_path, 
                                                           img_path=img_path, 
                                                           new_fig=False)
            llh_df_tmp.append(llh)
            llh_df_OS_tmp.append(llh_OS)
            
            if LB != None:
                all_param_df.append(param_LB)
            else:
                all_param_df.append(param_LB.iloc[:-1,:])
                
            all_SR_df.append(result_LB)
        plt.savefig(img_path + "subplots_trial" + trial + "_split_date="+split_date+"_plot.png")
        
        
        # plot different LB on same graph
        LB_lst2 = LB_lst.copy()[:-2]
        plot_same_split_date(trial, LB_lst2, maturities, forward_df,
                             split_date, parameters_path="parameters\\",
                             img_path="images\\", new_fig=True)
        
        all_SR_df = pd.concat(all_SR_df, axis=1)
        all_SR_df.columns = LB_lst
        
        
        # shadow rate difference & difference squared
        SR_diff = all_SR_df - all_SR_df.shift(1)
        SR_diff_sq = SR_diff - SR_diff.shift(1)
        
        for i in range(len(LB_lst)):
            LB = LB_lst[i]
            SR_diff_LB = SR_diff.iloc[:,i]
            SR_diff_sq_LB = SR_diff_sq.iloc[:,i]
            plt.figure(figsize=(10,6))
            plt.suptitle("LB = " + str(LB))
            plt.subplot(211)
            plt.plot(dateList_all, SR_diff_LB)
            plt.title("shadow rate 1st order difference")
            plt.grid("on")
            plt.subplot(212)
            plt.plot(dateList_all, SR_diff_sq_LB)
            plt.title("shadow rate 2nd order difference")
            plt.grid("on")
            plt.savefig(img_path + "SRdiff_trial" + trial + "_split_date="+split_date+"LB=_"+str(LB)+"_plot.png")
            
        SR_diff.to_excel(result_path + "trial" + trial + "split_date="+split_date+ "SRdiff.xlsx", sheet_name="SR_diff")
        SR_diff.to_excel(result_path + "trial" + trial + "split_date="+split_date+ "SRdiff.xlsx", sheet_name="SR_diff_squared")
        
    
        # parameters results
        all_param_df = pd.concat(all_param_df,axis=1)
        all_param_df.columns = LB_lst
        all_param_df.index = ["rhoP11", "rhoP12", "rhoP13", "rhoP21", "rhoP22",
                              "rhoP23", "rhoP31", "rhoP32", "rhoP33",
                              "muP1", "muP2", "muP3",
                              "rhoQ1", "rhoQ2",
                              "sigma11", "sigma21", "sigma22", "sigma31", "sigma32", "sigma33",
                              "delta0",
                              "sqrt_omega"]
        
        all_param_df.to_excel(result_path + "trial" + trial + "split_date="+split_date+ "all_parameters.xlsx")
        all_SR_df.to_excel(result_path + "trial" + trial + "split_date="+split_date+ "SR.xlsx")
        llh_df.append(llh_df_tmp)
        llh_df_OS.append(llh_df_OS_tmp)
    
    # likelihood results
    llh_df = pd.DataFrame(llh_df, index=split_date_lst, columns=LB_lst).T
    llh_df.to_excel(result_path + "trial" + trial + "_all_loglikelihood(IS).xlsx")
    llh_df_OS = pd.DataFrame(llh_df_OS, index=split_date_lst, columns=LB_lst).T
    llh_df_OS.to_excel(result_path + "trial" + trial + "_all_loglikelihood(OS).xlsx")

    
    # plot results for different split_date on same graph
    for LB in LB_lst:
        plt.figure(figsize=(10,4))
        for i in range(len(split_date_lst)):
            split_date = split_date_lst[i]
            color = color_lst[i]
            plot_SR_v2(trial, 
                       LB, 
                       maturities, 
                       forward_df, 
                       split_date,
                       parameters_path=parameters_path, 
                       img_path=img_path, 
                       new_fig=False,
                       color=color)
            
        plt.legend(split_date_lst)
        plt.title("LB = "+str(LB))
        plt.savefig(img_path + "splitDate_comparison" + "subplots_trial" + trial + "LB="+ str(LB) +"_plot.png")
        
        
        