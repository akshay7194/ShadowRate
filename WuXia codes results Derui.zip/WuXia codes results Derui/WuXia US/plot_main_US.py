# -*- coding: utf-8 -*-
"""
Created on Thu Oct 29 21:02:59 2020

@author: Derui
"""
from plot_shadow_rates import *

if __name__ == "__main__":
    # takes about a minute to run
    # parameters specification
    key = "fFQBXFkYyxsDvRibinGz"
    quandl.ApiConfig.api_key = key

    sdate = '2006-01-01'
    edate = '2020-09-01'
    
    maturities = np.array([1, 3, 6, 12, 24, 36, 60, 84, 120, 240, 360])/12
    forward_df = get_forward_df(key, sdate, edate, maturities)
    
    # LB_lst = [-2.5, -1.25, -0.75, -0.25, 0.0, 0.25, 0.75, 1.25, 2.5]
    LB_lst = [-2.5, -1.25, -0.75, -0.25, -0.1, 0.0, 0.1, 0.25, 0.75, 1.25, 2.5]
    
    split_date_lst = ["201401", "201801", "202010"]
    color_lst = ["b", "g", "y"]

    trial = "20201008"
    img_path = "images\\"
    result_path = "results\\"
    parameters_path = "parameters\\"
    
    
    gen_all_result(forward_df,
                   maturities,
                   trial,
                   LB_lst,
                   split_date_lst,
                   color_lst,
                   img_path=img_path,
                   result_path=result_path,
                   parameters_path = parameters_path)